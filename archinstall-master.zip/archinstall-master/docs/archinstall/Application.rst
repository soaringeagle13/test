.. _archinstall.Application:

archinstall.Application
=======================

This class enables access to pre-programmed application configurations.
This is not to be confused with :ref:`archinstall.Profile` which is for pre-programmed profiles for a wider set of installation sets.


.. autofunction:: archinstall.Application
