import setuptools  # type: ignore

setuptools.setup(package_data={'archinstall': ['locales/*','locales/*/*','locales/*/*/*']}, include_package_data=True)
